"ui";
var ver = 1.0
var url = "https://lmsdscav.github.io/zwgiko.tt"
var ph = "/sdcard/"
inui()
function startui(){
    ui.layout(
        <scroll>
        <vertical padding="10">
        <text text="作文技巧" textSize="66sp" textColor="#000000"/>
        <text text="loading...正在加载中。。。" id="loading_startui_datool" textSize="50sp" textColor="#0000ff"/>
        </vertical>
        </scroll>
        )
        alll()
        function df() {
            var dd = getLSD()
            if(dd=="loading."){upLSD("loading..")}
             if(dd=="loading.."){upLSD("loading...")}else{upLSD("loading.")}
       } 
       function alll(){setTimeout(function(){inui()},1000)}
        function upLSD(msg){ui.loading_startui_datool.text(msg)}
        function getLSD(){return ui.loading_startui_datool.getText()}
    }
    var ss2 = "还没加载成功呢...○"
function inui(){
    ui.layout(
        <vertical bg="#292f57">
        
        <text text="写作秘籍" textSize="50sp" textColor="#ffffff"/>
        <text id="d0" text="加载需要较长的时间，请保证网络通畅" textSize="16sp" textColor="#00ff00"/>
        
        
        <vertical>
        <button id="bn1" text="刷新"/>
        <horizontal>
        <scroll>
        <text text="加载中，请耐心等待一定时间... ○"id="idp1" textSize="20sp" w="234sp" textColor="#f1f1f1"/>
        </scroll>
        <button id="csi1" text="占时清除[点击刷新即可再次显示]" w="auto" h="auto" textSize="16sp"/>
        <!--<button id="bk1" text="返回启点"/>-->
        </horizontal>
        </vertical>
        
        </vertical>
        )
        ui.csi1.click(()=>{
            ui.idp1.text("")
            })
        threads.start(function(){
            var ss1 = http.get(url)
             ss2 = ss1.body.string()
            ss2 = am(ss2,"*1a","1a*")
            ui.idp1.text(ss2)
            
            })
       ui.bn1.click(()=>{
           inui()
                ui.idp1.text(ss2)
                })
      /* ui.bk1.click(()=>{
           ui.idp1.text("")
           ui.idp1.text(" ")
           setTimeout(function(){
           ui.idp1.text(ss2)
           },666)
           })*/
       }
        //ui.idp1.text("加载中(可能需要一定时间)...○")
    

    function am(a, b, c, f, e) {
    a = a.split(b);
    var d = "";
    if (e < a.length && e != null) {} else {
        e = a.length;
    }
    if (f == null) {
        f = 1;
    }
    for (i = f; i < e; i++) {
        tmp = a[i].split(c);
        if (tmp.length > 1) {
            d += tmp[0];
        }
    }
    return d;
}
   //\n